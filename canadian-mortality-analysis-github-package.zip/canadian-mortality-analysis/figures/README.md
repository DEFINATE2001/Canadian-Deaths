# Figures Folder

This folder can be used to store exported charts or screenshots from the Quarto report.

Optional examples:
- class distribution plots
- mortality trend plots
- PCA cluster plots
- forecast charts
