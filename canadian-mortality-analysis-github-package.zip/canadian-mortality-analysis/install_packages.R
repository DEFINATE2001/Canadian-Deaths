# Install required R packages for this project

install.packages(c(
  "tidyverse",
  "janitor",
  "scales",
  "patchwork",
  "tidymodels",
  "glmnet",
  "tsibble",
  "fable",
  "feasts",
  "vip",
  "MASS",
  "knitr",
  "stringr",
  "ggrepel",
  "modeltime"
))
