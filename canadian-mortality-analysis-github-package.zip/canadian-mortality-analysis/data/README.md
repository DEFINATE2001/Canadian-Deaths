# Data Folder

Place the dataset file here and rename it to:

```text
CanadaDeaths.csv
```

The Quarto analysis reads the file using:

```r
read_csv("data/CanadaDeaths.csv")
```

The raw dataset is not included in this repository.
