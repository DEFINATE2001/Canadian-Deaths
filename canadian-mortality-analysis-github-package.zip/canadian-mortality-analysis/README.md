# Canadian Mortality Analysis (2000–2024)

## Project Overview
This project analyzes Canadian mortality patterns from 2000 to 2024 using R and Quarto.  
The goal is to explore how causes of death vary over time and across demographic groups, then apply statistical and machine learning methods to identify patterns and forecast future mortality trends.

This project is designed as a recruiter-facing portfolio project because it demonstrates:

- data cleaning and feature engineering
- exploratory data analysis
- clustering and PCA
- regression modeling
- time-series forecasting
- reproducible reporting with Quarto

---

## Main Questions
This project focuses on the following questions:

1. What are the major causes of death in Canada over time?
2. How do mortality patterns differ by age group and sex?
3. Can causes of death be grouped based on similar time-series patterns?
4. Which demographic and disease factors are associated with higher mortality counts?
5. Can future mortality trends be forecasted using time-series models?

---

## Methods Used
The analysis includes:

- data cleaning and preprocessing
- feature engineering
- exploratory visualizations
- cross-tabulations
- PCA for dimensionality reduction
- K-Means clustering for grouping causes of death
- Negative Binomial regression
- Elastic Net regularized regression
- hierarchical time-series forecasting

---

## Repository Structure

```text
canadian-mortality-analysis/
│
├── README.md
├── canadian_mortality_analysis.qmd
├── requirements.txt
├── .gitignore
│
├── data/
│   └── README.md
│
└── figures/
    └── README.md
```

---

## Dataset Setup

The dataset is not included in this repository because public datasets can be large and may have redistribution rules.

To run the project:

1. Download the Canadian causes of death dataset.
2. Rename the file to:

```text
CanadaDeaths.csv
```

3. Place it inside the `data/` folder:

```text
data/CanadaDeaths.csv
```

The Quarto file reads the dataset using:

```r
read_csv("data/CanadaDeaths.csv")
```

---

## Environment Setup

### 1. Install R
Install R from:

```text
https://cran.r-project.org/
```

### 2. Install RStudio or Positron
Recommended for working with Quarto projects.

### 3. Install Quarto
Install Quarto from:

```text
https://quarto.org/
```

### 4. Install required R packages

Open R or RStudio and run:

```r
install.packages(c(
  "tidyverse",
  "janitor",
  "scales",
  "patchwork",
  "tidymodels",
  "glmnet",
  "tsibble",
  "fable",
  "feasts",
  "vip",
  "MASS",
  "knitr",
  "stringr",
  "ggrepel",
  "modeltime"
))
```

---

## How to Run the Analysis

From the project folder, run:

```bash
quarto render canadian_mortality_analysis.qmd
```

This will generate an HTML report from the Quarto file.

You can also open the `.qmd` file in RStudio and click **Render**.

---

## Key Skills Demonstrated

- R programming
- Quarto reporting
- data wrangling with tidyverse
- statistical modeling
- machine learning workflow
- time-series analysis
- visualization and interpretation
- reproducible project organization

---

## Project Status
The current version includes the complete Quarto analysis file and setup instructions.  
Future improvements may include:

- adding an interactive dashboard
- improving model comparison tables
- adding a rendered HTML report
- adding more interpretation for forecasting results

---

## Author
**Definate Mudarikwa**  
Post-Baccalaureate Diploma in Applied Data Science  
Thompson Rivers University
